/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

/**
 *
 * @author Bisho
 */
interface DisplayManager {
    public void show_screen1();
    void show_screen2(ComboFlights cf[]);
    void showScreen3(ComboFlights cmb, String nm, int tick, String dt, String ref, String mon);
}

    