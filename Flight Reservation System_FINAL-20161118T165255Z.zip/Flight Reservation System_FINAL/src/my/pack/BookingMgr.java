/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

import java.io.*;
import java.util.*;

/**
 *
 * @author Baisakhi
 */
public class BookingMgr {  
String bookref;
FileReader fr=null;
BufferedReader br=null;
FileWriter fw=null;
BufferedWriter bw=null;
PrintWriter pw=null;
String days[]={"Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"};
String seatcsv="seats.csv";

    boolean seatsAvailability(Flight dm,int tickets,int date,String month) {
        //if 'tickets' seatsAvaialble on 'date'  - check from seats.csv
        int i,flag=0,tarikh,seats,mahina;
        String line,fnum,dte,mon,day,seat,dat;
        try
        {
        fr=new FileReader(seatcsv);
        br=new BufferedReader(fr);
        for(i=0;i<1126;i++)
        {
            line=br.readLine();
            if(i>0)
            {
                flag=0;
                StringTokenizer tk=new StringTokenizer(line,"|");
                fnum=tk.nextToken();
                dte=tk.nextToken();
                StringTokenizer tkn=new StringTokenizer(dte,"/");
                mon=tkn.nextToken();
                mahina = Integer.parseInt(mon);
                
                dat=tkn.nextToken();
                tarikh=Integer.parseInt(dat);
                
                day=tk.nextToken();
                seat=tk.nextToken();
                seats=Integer.parseInt(seat);
                dm.flightNum = dm.flightNum.replaceAll("\\s+","  ");
                fnum=fnum.trim().replaceAll("\\s+","  ");
                
                if(dm.flightNum.equals(fnum) && tarikh==date && mahina == Integer.parseInt(month.trim()))
                {  if(tickets<=seats)
                        flag=1; //valid
                    break;
                }
            }
        }
        br.close();
        }
        catch(FileNotFoundException e)
        {
           System.out.println("NO SUCH FILE EXISTS"); 
        }
        catch(IOException e)
        {
            System.out.println("IO ERROR!!!");
        }
        if(flag==1)
            return true;
        else 
            return false;
    }

    public String book(ComboFlights selectedCombo, int tick, String nm,String date,String month) {
        /*    1.generate Booking Refernce Number
              2.save Booking
              3.updateSeats(selectedCombo)
        */
        date=date+" / " + month+" /2016";
        int dif,flag=0;
        int ref1=(int)(1000*Math.random());
        int ref2=(int)(1000*Math.random());
        //String reff=String.valueOf(ref1);
        String reff = String.format("%04d", ref1);
        String refff = String.format("%04d", ref2);
        
        bookref="FL"+reff+"SG"+refff;
        try
        {
             File f=new File("bookings.csv");
        
        if(f.exists() && !f.isDirectory())
        {
            flag=1;
        }
        else
        {
            flag=0;
        }
        FileWriter frr=new FileWriter(f,true);
        BufferedWriter bwr=new BufferedWriter(frr);
        PrintWriter pwr=new PrintWriter(bwr);
        if(flag==0)
        {
            pwr.println("NameOfPax | Tickets | DateOfJourney | BookingReferenceNumber | Source | DomesticFlight | Via | IntlFlight | Destination ");
            pwr.println(nm+"  |  "+tick+"  |  "+date+"  |  "+bookref+"  |  "+selectedCombo.domestic.depCity+"  |  "+selectedCombo.domestic.flightNum+"  |  "+selectedCombo.international.depCity+"  |  "+selectedCombo.international.flightNum+"  |  Singapore ");
        }
       
        else
            pwr.println(nm+"  |  "+tick+"  |  "+date+"  |  "+bookref+"  |  "+selectedCombo.domestic.depCity+"  |  "+selectedCombo.domestic.flightNum+"  |  "+selectedCombo.international.depCity+"  |  "+selectedCombo.international.flightNum+"  |  Singapore ");
            
        pwr.close();
        }
         catch(FileNotFoundException e)
        {
            System.out.println("NO SUCH FILE EXISTS");
        }
        catch(IOException e)
        {
            System.out.println("IO ERROR!!!");
        }
        updateSeats(selectedCombo,date,tick,month);
        return bookref;
    }

    public void updateSeats(ComboFlights selectedCombo,String date,int tick, String month) {
        int i,flag=0,tarikh=0,seats=0,fd1,mahina;
        String fdate1,fdt1;
        String line,fnum=null,dte,mon,day,seat=null,dat,pday=null;
        StringTokenizer tokn1=new StringTokenizer(date);
        String fdate=tokn1.nextToken();
        fdate1=fdate;
        if(fdate.charAt(0)=='0')
            fdate1=fdate.substring(1,2);
        fd1=Integer.parseInt(fdate1);
        fd1=fd1+selectedCombo.change;
        
        if(fd1<10)
            fdt1="0"+fd1;
        else
            fdt1=""+fd1;
        
        File f=new File("temp.csv");
        try
        {
            fw=new FileWriter("temp.csv",true);
            fr=new FileReader(seatcsv);
            br=new BufferedReader(fr);
            bw=new BufferedWriter(fw);
            pw=new PrintWriter(bw);
            pw.println("FlightNum|date|day|seats");
            for(i=0;i<1126;i++)
            {
                line=br.readLine();
                if(i>0)
            {
                flag=0;
                StringTokenizer tk=new StringTokenizer(line,"|");
                fnum=tk.nextToken();
                dte=tk.nextToken();
                StringTokenizer tkn=new StringTokenizer(dte,"/");
                mon=tkn.nextToken();
                mahina = Integer.parseInt(mon);
                dat=tkn.nextToken();
                tarikh=Integer.parseInt(dat);
                day=tk.nextToken();
                seat=tk.nextToken();
                seats=Integer.parseInt(seat);
                pday=days[(tarikh-1)%7];
                
               
                if(dat.length()==1)
                    dat="0"+dat;
                 
                String fl = fnum;
                fnum=fnum.trim().replaceAll("\\s+","  ");
                selectedCombo.domestic.flightNum = selectedCombo.domestic.flightNum.trim().replaceAll("\\s+","  ");
                selectedCombo.international.flightNum = selectedCombo.international.flightNum.trim().replaceAll("\\s+","  ");
                
                
                if(((selectedCombo.domestic.flightNum.equals(fnum)) && dat.equals(fdate))&& mahina == Integer.parseInt(month.trim())||((selectedCombo.international.flightNum.equals(fnum)) && dat.equals(fdt1))&& mahina == Integer.parseInt(month.trim()))
                {   seats-=tick;
                    seat=String.valueOf(seats);
                    pw.println(fl+"|"+mon+"/"+tarikh+"/2016|"+pday+"|"+seats);
                    
                }
                else
                   pw.println(fl+"|"+mon+"/"+tarikh+"/2016|"+pday+"|"+seats); 
            }
        }
            br.close();
            pw.close();
        }
        
        catch(FileNotFoundException e)
        {
            System.out.println("NO SUCH FILE EXISTS");
        }
        catch(IOException e)
        {
            System.out.println("IO ERROR!!!");
        }
        
        try
        {
            fw=new FileWriter(seatcsv);
            fr=new FileReader("temp.csv");
            br=new BufferedReader(fr);
            bw=new BufferedWriter(fw);
            pw=new PrintWriter(bw);
            
            for(i=0;i<1126;i++)
            {
                line=br.readLine();
                pw.println(line);
            }
           
            br.close();
            pw.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("NO SUCH FILE EXISTS");
        }
        catch(IOException e)
        {
            System.out.println("IO ERROR!!!");
        }
        finally
        {
            f.delete();
        }
    }
}