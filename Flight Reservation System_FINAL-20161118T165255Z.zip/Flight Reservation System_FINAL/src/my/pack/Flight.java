/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

/**
 *
 * @author Basudeb
 */
public class Flight {
String depCity,arrCity,daysOfWeek,flightNum,depTime,arrTime;
Flight(String d,String ar,String w,String n,String t,String a)
{
depCity=d.trim();
arrCity=ar.trim();
daysOfWeek=w;
flightNum=n.trim();
depTime=t;
arrTime=a;
}
}
