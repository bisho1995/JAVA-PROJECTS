/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

import java.util.*;

/**
 *
 * @author Avimita
 */
public class FRSmanager {
   /**
    *
    */
  String date,source,seats,nm,ref,month;
  ComboFlights[] cf=new ComboFlights[1000]; 
  Flight dfl[]=new Flight[1000];
  Flight infl[]=new Flight[1000];
   ComboFlights sc;
  int len;
  DataMgr dtm;
  TDisplayManager tm;
  GDisplayManager dm1;
  SearchManager srm;
  BookingMgr bm = new BookingMgr();
  String spicejet,silkair;
  Scanner sc1=new Scanner(System.in);
  String choice;
  FRSmanager(){
   dtm=new DataMgr();
   //srm=new SearchManager();
   bm = new BookingMgr();   
  }
  
    public static void main(String args[])
    {
        FRSmanager frsm=new FRSmanager();
        frsm.len=args.length;
        frsm.spicejet=args[0];
        frsm.silkair=args[1];
        if (frsm.len==3)
            frsm.choice = args[2];
        else
            frsm.choice = "swing";
        frsm.dtm=new DataMgr();
        frsm.bm=new BookingMgr();
        frsm.dtm.getSeatsAvailability(frsm.spicejet,frsm.silkair);
        frsm.srm=new SearchManager(frsm.dtm);
        frsm.dfl=frsm.dtm.readSpicejet();
        frsm.infl=frsm.dtm.readSilkair();
        
        frsm.start(frsm);
     }
    
    void search(String a,String b,String c, String d)
    {
       source=a;
       date=b;
       seats=c;
       month = d;
       cf=srm.search_in_database(dfl,infl,seats,date,source,month);
        if(choice.equalsIgnoreCase("text"))
        {   
            tm.show_screen2(cf);
        }
        else 
            dm1.show_screen2(cf);
        
    }
   
    void book(ComboFlights selectedCombo) {
        sc=selectedCombo;
        if(choice.equalsIgnoreCase("text"))
        {   
            nm=tm.getName();
        }
        else
        {
            nm=dm1.getName();
        }
        ref=bm.book(selectedCombo,Integer.parseInt(seats),nm,date,month);
        
    }
        
    void showScreen3() {
         if(choice.equalsIgnoreCase("text"))
            tm.showScreen3(sc,nm,Integer.parseInt(seats),date,ref,month);
         else
            dm1.showScreen3(sc,nm,Integer.parseInt(seats),date,ref,month);
         
    }


   void start(FRSmanager frs) {
       //frs.bm=new BookingMgr();     
       frs.tm=new TDisplayManager(this,this.srm);
       frs.dm1=new GDisplayManager(this,this.srm);
     
        if(choice.equalsIgnoreCase("text"))
        {
            tm.show_screen1();
           
        }
        else
            dm1.show_screen1(); 
    }
}
