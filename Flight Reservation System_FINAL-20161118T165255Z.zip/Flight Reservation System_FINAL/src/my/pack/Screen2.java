/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
//import javafx.geometry.Bounds;
//import javafx.scene.layout.Border;
import javax.swing.ButtonGroup;
import javax.swing.ScrollPaneLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 *
 * @author Bisho
 */
public class Screen2 extends javax.swing.JFrame {
    FRSmanager frsm;SearchManager srm;
public Font boldFont ;
public String fld,fli,itd,Name;
ComboFlights selectedCombo;
public ComboFlights ck[];
    /**
     * Creates new form Screen2
     */
JRadioButton b2[];
    public Screen2(FRSmanager mgr,SearchManager sr) {
        initComponents();
        frsm=mgr;
        srm=sr;
        b2= new JRadioButton[srm.c+1];
        this.setIconImage(new ImageIcon(getClass().getResource("icp.png")).getImage());
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Screen1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Screen1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Screen1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Screen1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        txt = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        proceed = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Label = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Available Flights");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setBackground(null);
        jScrollPane2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane2.setAutoscrolls(true);
        jScrollPane2.setMaximumSize(new java.awt.Dimension(500, 500));
        jScrollPane2.setName(""); // NOI18N
        jScrollPane2.setOpaque(false);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(500, 500));

        jPanel2.setBackground(new java.awt.Color(102, 102, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setMinimumSize(new java.awt.Dimension(100, 40));
        jPanel2.setName(""); // NOI18N
        jPanel2.setOpaque(false);
        jPanel2.setPreferredSize(new java.awt.Dimension(600, 700));
        jPanel2.setRequestFocusEnabled(false);
        jPanel2.setLayout(null);
        jScrollPane2.setViewportView(jPanel2);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 770, 260));

        txt.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 14)); // NOI18N
        txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtActionPerformed(evt);
            }
        });
        txt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtKeyPressed(evt);
            }
        });
        getContentPane().add(txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 540, 250, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 620, 120, 40));

        jLabel2.setFont(new java.awt.Font("Aharoni", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Enter Your Name: ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 540, 130, 30));

        proceed.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        proceed.setText("Proceed");
        proceed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                proceedActionPerformed(evt);
            }
        });
        getContentPane().add(proceed, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 610, 230, 50));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/my/pack/scree2.jpg"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -180, 1220, 1070));

        Label.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        getContentPane().add(Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 180, -1, -1));
        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, -30, -1, -1));

        setSize(new java.awt.Dimension(1236, 751));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void proceedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_proceedActionPerformed

        int flag=0,i1=0,i;
       // Name=txt.getText();
       // System.out.println(srm.c);
                    for(i=0;i<srm.c;i++)
                    {
                       // System.out.println("=======================================================");
                        if(b2[i].isSelected())
                        {
                            
                            flag=1;
                            i1=i;
                        }
                    }
                    //SearchManager.c=0;
                    if(flag==1)
                    {
                        selectedCombo=ck[i1];
                        if(txt.getText().equals(""))
                            JOptionPane.showMessageDialog(new JFrame(),"Please Enter Your Name","Warning",JOptionPane.WARNING_MESSAGE);
                        else{
                        Name=txt.getText();
                        frsm.book(selectedCombo);
                       // txt.setText("");
                        frsm.showScreen3();
                        this.setVisible(false);
                        }
                    }    
                    else
                    {//    proceed.setText("Please select one of the above");
                     if(txt.getText().equals(""))
                            JOptionPane.showMessageDialog(new JFrame(),"Please Enter Your Name And Select One Of The Options","Warning",JOptionPane.WARNING_MESSAGE);
                     else
                     {JOptionPane.showMessageDialog(new JFrame(),"Please Select One Of The Options","Warning",JOptionPane.WARNING_MESSAGE);
                    Name=txt.getText();}
                     revalidate();  
                    }
    }//GEN-LAST:event_proceedActionPerformed

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        proceed.setText("Proceed");
    }//GEN-LAST:event_jLabel1MouseClicked

    private void txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActionPerformed
        proceed.setText("Proceed");
    }//GEN-LAST:event_txtActionPerformed

    private void txtKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtKeyPressed
        proceed.setText("Proceed");
    }//GEN-LAST:event_txtKeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setVisible(false);
        frsm.start(frsm);
    }//GEN-LAST:event_jButton1ActionPerformed

   public  void show_sorted_combo(ComboFlights cf[])
    { 
        Font labelFont1;
        Font labelFont2;
        Font labelFont4;
        ck=cf;
        int ai,ad,id,td;
        //Create three radio buttons   
		JRadioButton b1[] = new JRadioButton[20];
                JLabel l1[]=new JLabel[srm.c+1];
            JLabel l2[]=new JLabel[srm.c+1];
            JLabel l3[]=new JLabel[srm.c+1];
            JLabel l4[]=new JLabel[srm.c+1];
                    jPanel2.setLayout(null);
                jScrollPane2.setBounds(0,0,1000,1000);
                JLabel pic=new JLabel("35w564q6");
            pic.setBounds(0,0,1000,1000);
           
            jPanel2.add(pic);
            pic.revalidate();
            ImageIcon newIcon= new ImageIcon("doe.jpg");
    pic.setIcon(newIcon);
    jPanel2.revalidate();
            jScrollPane2.revalidate();
		ButtonGroup myButtonGroup = new ButtonGroup();
                String sp="  ";
               // System.out.println(srm.c);
                for( int i=0;i<srm.c;i++)
                {
                   b1[i]=new JRadioButton();
                   b1[i].setBounds(1,100*i+10,75,75);
                   b1[i].setMargin(new Insets(65, 30, 65, 0));
                   Color q=jPanel2.getBackground();
                   b1[i].setBackground(q);
                   int ss=cf[i].international.depCity.length();
                   itd=cf[i].international.depCity.substring(0, ss-6);
                   itd=itd.toUpperCase();
                   makestr(i);
                   ai =calctime(ck[i].international.depTime,ck[i].international.arrTime);
                   ad =calctime(ck[i].domestic.depTime,ck[i].domestic.arrTime);
                   id =calctime(ck[i].domestic.arrTime,ck[i].international.depTime);
                   td=((ad%100)+(ai%100)+(id%100))%60+((((ad/100)+(ai/100)+(id/100))+((ad%100)+(ai%100)+(id%100))/60)*100);
                   
                   int ji=(td%100)-30;
                   if(ji<0)
                           {
                          td=(td/100)-3;
                          ji+=60;
                   }
                   else
                       td=(td/100)-2;
                   l1[i]=new JLabel(fld);
                   l2[i]=new JLabel(fli);
                   l4[i]=new JLabel(td+"h"+ji+"m");
                   l3[i]=new JLabel("=====================================================================================================================");
                   l1[i].setBounds(90,100*i+5,1000,60);
                   l2[i].setBounds(90,100*i+45,1000,60);
                   l3[i].setBounds(0,100*i+75,1000,50);
                   l4[i].setBounds(625,100*i+30,1000,50);
                   l1[i].setForeground(Color.white);
                   l2[i].setForeground(Color.white);
                   l4[i].setForeground(Color.white);
                   labelFont1=l1[i].getFont();
                   labelFont2=l2[i].getFont();
                   labelFont4=l4[i].getFont();
                   l1[i].setFont(new Font(labelFont1.getName(), Font.BOLD, 14));
                   l2[i].setFont(new Font(labelFont2.getName(), Font.BOLD, 14));
                   l4[i].setFont(new Font(labelFont4.getName(), Font.BOLD, 14));
                   l3[i].setFont(new Font("=====================================================================================================================", Font.BOLD, 14));
                   myButtonGroup.add(b1[i]);
                   jPanel2.add(b1[i]);
                   jPanel2.add(l1[i]);
                   jPanel2.add(l2[i]);
                   jPanel2.add(l3[i]);
                   jPanel2.add(l4[i]);
                   jPanel2.setOpaque(true);
                   jScrollPane2.setOpaque(true);
                   b1[i].revalidate();
            l1[i].revalidate();
            l2[i].revalidate();
            l3[i].revalidate();
            l4[i].revalidate();
            jPanel2.revalidate();
            jScrollPane2.revalidate();
            jScrollPane2.setVisible(true);
            setVisible(true);
                }
                
                b2=b1;
                myButtonGroup.clearSelection();
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);}});//end WindowListener
        
    }
   void makestr(int as)
                        {
                       fli= ck[as].international.flightNum;
                            int le=fli.length();
                            int io;
                            while(fli.length()<12)
                            {
                            fli=fli+"      ";
                            }
                            fli=fli+itd;
                            le=fli.length();
                            if(itd.length()<=7)
                                fli=fli+"   ";
                            for(io=le;io<31;io++)
                            {
                            fli=fli+" ";
                            }
                            fli=fli+"SINGAPORE";
                            le=fli.length();
                            for(io=le;io<54;io++)
                            {
                            fli=fli+" ";
                            }
                            if(itd.length()<=7)
                                fli=fli+"    ";
                            fli=fli+ck[as].international.depTime;
                            le=fli.length();
                            if(itd.length()<=7)
                                fli=fli+"    ";
                            for(io=le;io<77;io++)
                            {
                            fli=fli+" ";
                            }
                            fli=fli+ck[as].international.arrTime;
                            fld= ck[as].domestic.flightNum+"    "+ck[as].domestic.depCity;
                            le=fld.length();
                            for(io=le;io<38;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.arrCity;
                            le=fld.length();
                            if(ck[as].domestic.arrCity.length()<=7)
                                fld=fld+"     ";
                            for(io=le;io<60;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.depTime;
                            le=fld.length();
                            if(ck[as].domestic.arrCity.length()<=7)
                                fld=fld+"    ";
                            for(io=le;io<83;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.arrTime;
                        }
    int calctime(String y,String z)
    {
        int ti=0,yy,zz,l1,l2;
        if(z.length()!=4)
        {
            z=z.substring(0,4);
         }
        yy=Integer.parseInt(y);
        zz=Integer.parseInt(z);
        l1=yy%100;
        l2=zz%100;
        yy/=100;
        zz/=100;
        if(z.length()==4 && zz>yy)
        {
        if(l2>=l1)
            ti=(100*(zz-yy))+l2-l1;
        else
            ti=(100*(zz-yy-1))+60-l1+l2;
        }
        else
        {
        if(l1==0){
            yy=24-yy;
        }
        else{
            yy=24-yy-1;
            l1=60-l1;
        }
        l1+=l2;
        yy+=zz;
        yy+=l1/60;
        l1=l1%60;
        ti=(100*yy)+l1;
        }
        return ti;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton proceed;
    private javax.swing.JTextField txt;
    // End of variables declaration//GEN-END:variables
}