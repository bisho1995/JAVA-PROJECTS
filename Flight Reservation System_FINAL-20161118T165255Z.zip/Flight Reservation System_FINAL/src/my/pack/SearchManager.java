/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;
import java.util.StringTokenizer;
/**
 *
 * @author Baisakhi
 */
public class SearchManager {
    FRSmanager myMgr = new FRSmanager();
    DataMgr dmr;
    int c;// c is counter
    int tm=0,tm1=0,tmnew;//tm gets transit time of domestic. tm1 gets transit time of international
    
    SearchManager(DataMgr dm)
    {
        dmr=dm;
    }
ComboFlights Combo[]=new ComboFlights[1000];
//BookingMgr bm=new BookingMgr();


public ComboFlights[] search_in_database(Flight dm[],Flight intl[],String num, String date, String source, String month) {
      int i,i1,j1,j=-1;
      c=0;
      boolean res=false;
      //int dt=Integer.parseInt(date);
      String days[];
        /* ---------------CODE--------------------- */
       if(month=="09")
            days= new String[]{"Thursday","Friday","Saturday","Sunday","Monday","Tuesday","Wednesday"};
        else if(month == "10")
            days= new String[]{"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
       else
            days= new String[]{"Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday","Monday"};
            
        for(i=0;i<dmr.count;i++)//dmr.count gives no of flights in domestic(spicejet)
        {   if (!this.getDomFlight(dm[i], num,date, source, month, days)) //returns flights that much user criteria. If true flight is valid
                continue;
         
            for(j=0;j<dmr.count2;j++)//dmr.count2 gives number of flights in international (silkair). 
              this.getIntlFlight(dm[i],intl[j],date,days,num,month);//returns flights that much user criteria and domestic flight. If true flight is valid
            
        }
       /*SORT ACC TO TOTAL TIME*/ 
       sort();
       return Combo; 
    }

    public boolean getDomFlight(Flight dm,String num,String date, String source, String month, String days[]){
      int j1,j=-1;
      
      boolean res;
      int dt;
        dt=Integer.parseInt(date); //date chosen by user passed from frsmanager
            if(dm.depCity.equalsIgnoreCase(source))
               {   String day=days[(dt-1)%7];
                   int flag=0;//flag is raised if day is same as that of flight operation
                   StringTokenizer d1=new StringTokenizer(dm.daysOfWeek,", ");
                   if(dm.daysOfWeek.equalsIgnoreCase("DAILY"))//if daily flight valid all days
                       flag=1;
                   else
                   {
                       while(d1.hasMoreTokens())
                        {   
                            String dd1=d1.nextToken();
                            if(day.equalsIgnoreCase(dd1))//checks validity of day
                                flag=1;
                           
                        }
                   }
                  
                   if(flag==0)
                    return false;
                    
                   res=myMgr.bm.seatsAvailability(dm,Integer.parseInt(num),dt,month);
                    
                   return res;
      }
      else 
                return false;
    }
            
     
    public void getIntlFlight(Flight dm,Flight intl,String date, String days[], String num, String month){
        
                
                boolean res;
                int dt=Integer.parseInt(date); //date given by user
               
                StringTokenizer d2=new StringTokenizer(intl.depCity);
                String dc=d2.nextToken();//dc = depcity for international
                
                tm=0;tm1=0; tmnew=0;
                /**TRANSIT TIME CALC**/
                transitTime(dm,intl);
                
                if(dc.equalsIgnoreCase(dm.arrCity))//dep city of intl == arrival city of domestic
               {String day=days[(dt-1)%7];
                int flag=0;//flag raise when all conditions satisfied
                StringTokenizer d1=new StringTokenizer(intl.daysOfWeek,",");
                int flag1=0;
                    while(d1.hasMoreTokens())
                        {String dd1=d1.nextToken();
                         if((day).startsWith(dd1))
                            {if(((tm1-tm)<120)||((tm1-tm)>360))//checks if transit time is between 2 and 6 hours
                                    flag=0;
                             else
                                {   flag=1;
                                    break;
                                }
                            }
                            else if((days[(dt)%7]).startsWith(dd1))
                            {   tmnew=24*60+tm1;
                                if(((tmnew-tm)<120)||((tmnew-tm)>360))
                                 flag=0;
                                else
                                {   flag=1;
                                    flag1=1;//change of day occurs
                                    break;
                                }
                            }
                        }
                     
                   if(flag==0)
                      return;
                   
                   int change=0;//change checks if the date has changed during flight
                   if(flag1==1)
                   {dt=dt+1;change=1;}
                    res=myMgr.bm.seatsAvailability(intl,Integer.parseInt(num),dt,month);
                    if(res)
                    { 
                      Combo[c++]=new ComboFlights(dm,intl,change);
                      
                    }
                    
               }
         
    }
    
    /**TRANSIT TIME CALC**/
    public void transitTime(Flight dm,Flight intl){
        
                /*Calculation of domestic flight time*/
                String ftm=dm.arrTime.substring(0,2);
                if(ftm.charAt(0)=='0')
                    ftm=dm.arrTime.substring(1,2);
                
                String ltm=dm.arrTime.substring(2,4);
                if(ltm.charAt(0)=='0')
                   ltm=dm.arrTime.substring(3,4);
                tm+=Integer.parseInt(ftm)*60;
                tm+=Integer.parseInt(ltm);
                
                /*Calculation of international flight time*/
                
                ftm=intl.depTime.substring(0,2);
                if(ftm.charAt(0)=='0')
                    ftm=intl.depTime.substring(1,2);
                ltm=intl.depTime.substring(2,4);
                    if(ltm.charAt(0)=='0')
                        ltm=intl.depTime.substring(3,4);
                tm1+=Integer.parseInt(ftm)*60+Integer.parseInt(ltm);
                //tmnew=24*60+tm1;
    }
    
    
    
    public void sort(){
        for(int i=0;i<c;i++)
        {
            for(int j=0;j<c-1;j++)
            {
                String dp=Combo[j].domestic.depTime;
                String dp1=dp.substring(0,2);
                if(dp1.charAt(0)=='0')
                    dp1=dp.substring(1,2);
                String dp2=dp.substring(2,4);
                if(dp2.charAt(0)=='0')
                    dp2=dp.substring(3,4);
                int tot1=Integer.parseInt(dp1)*60+Integer.parseInt(dp2);
                
                String dpi=Combo[j].international.arrTime;
                if(dpi.length()>4)
                {
                    StringTokenizer tp=new StringTokenizer(dpi,"+");
                    dpi=tp.nextToken();
                }
                String dpi1=dpi.substring(0,2);
                int ext=0,hrsum;
                if(dpi1.charAt(0)=='0')
                {
                    dpi1=dpi.substring(1,2);
                    ext=24*60;
                }
                String dpi2=dpi.substring(2,4);
                if(dpi2.charAt(0)=='0')
                    dpi2=dpi.substring(3,4);
                hrsum=Integer.parseInt(dpi1)*60+ext + Integer.parseInt(dpi2);
                
                int dif1=hrsum-tot1;
                
                dp=Combo[j+1].domestic.depTime;
                dp1=dp.substring(0,2);
                if(dp1.charAt(0)=='0')
                    dp1=dp.substring(1,2);
                dp2=dp.substring(2,4);
                if(dp2.charAt(0)=='0')
                    dp2=dp.substring(3,4);
                tot1=Integer.parseInt(dp1)*60+Integer.parseInt(dp2);
                
                dpi=Combo[j+1].international.arrTime;
                if(dpi.length()>4)
                {
                    StringTokenizer tp=new StringTokenizer(dpi,"+");
                    dpi=tp.nextToken();
                }
                 dpi1=dpi.substring(0,2);
                 ext=0;
                if(dpi1.charAt(0)=='0')
                {
                    dpi1=dpi.substring(1,2);
                    ext=24*60;
                }
                 dpi2=dpi.substring(2,4);
                if(dpi2.charAt(0)=='0')
                    dpi2=dpi.substring(3,4);
                hrsum=Integer.parseInt(dpi1)*60+ext + Integer.parseInt(dpi2);
                
                int dif2=hrsum-tot1;
                ComboFlights temp;
                if(dif1>dif2)
                {
                    temp=Combo[j];
                    Combo[j]=Combo[j+1];
                    Combo[j+1]=temp;
                }
            }
        }
    }
}
