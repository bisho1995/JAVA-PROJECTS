/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

/**
 *
 * @author Basudeb
 */
public class ComboFlights {
      Flight domestic;
      Flight international;
      int change;//change checks if the date has changed during flight
      public ComboFlights(Flight dom,Flight intr,int ch)
      {
          domestic=dom;
          international=intr;
          change=ch;
      }
              
    }
