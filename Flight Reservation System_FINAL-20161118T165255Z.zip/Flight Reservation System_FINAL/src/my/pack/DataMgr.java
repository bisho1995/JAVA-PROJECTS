/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

/**
 *
 * @author Basudeb
 */
import java.util.*;
import java.io.*;
public class DataMgr {
    Flight dom[]=new Flight[88];
    Flight inter[]=new Flight[80];
    public int count=0,count2=0;
    void getSeatsAvailability(String spicejetcsv, String silkaircsv) {
        int i,p,j,flag,dt,y,d2,m2,x1=0,x=0,ex1=0,ex2=0,ex3=0,p1,dt1,y1,st=0,end=0,j1,count1,f1,flg=0,ihr,flgg=0;
        String ex_1,ex_2,ex_3,remark="",z,z1;
        String w[]=new String[7];
        String line=null;
        String d[]=new String[922];
        String mon[]={"JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
        String days[]={"Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"};
        String via,depCity,arrCity,daysOfWeek,flightNum,depTime,arrTime,Time,eFrom,eTill,m,m1,dtime,time1,meridian,hr,min,atime;
        FileReader fr=null;
        BufferedReader br=null;
        FileWriter fw=null;
        BufferedWriter bw=null;
        PrintWriter pw=null;
        for(i=1;i<=91;i++)
        {
            d[i]=days[(i-1)%7];
            //System.out.println(i+". "+d[i]);
        }
        try
        {
            fr=new FileReader(spicejetcsv);
            br=new BufferedReader(fr);
            File f = new File("seats.csv");
            if(f.exists() && !f.isDirectory()) 
                f1=1;
            else
                f1=0;
            fw=new FileWriter("seats.csv",true);
            bw=new BufferedWriter(fw);
            pw=new PrintWriter(bw);
            if(f1==0)
            pw.println("FlightNum|date|day|seats");
            for(i=0;i<62;i++)
            {
                flg=flgg=0;
                line=br.readLine(); 
                if(i>=5)
                {
                    StringTokenizer tokn = new StringTokenizer(line,"|");
                    depCity=tokn.nextToken();
                    arrCity= tokn.nextToken();
                    daysOfWeek=tokn.nextToken();
                    flightNum=tokn.nextToken();
                    //depTime=tokn.nextToken();
                    dtime=tokn.nextToken();
                    StringTokenizer sep=new StringTokenizer(dtime);
                    time1=sep.nextToken();
                    meridian=sep.nextToken();
                    StringTokenizer tk=new StringTokenizer(time1,":");
                    hr=tk.nextToken();
                    ihr=Integer.parseInt(hr);
                    min=tk.nextToken();
                    if(meridian.equals("PM"))
                    {
                        ihr+=12;
                        flg=1;
                    }
                    
                    if(flg==1)
                    {
                       depTime=String.valueOf(ihr)+min;
                    }
                    else
                       depTime=hr+min; 
                    //arrTime=tokn.nextToken();
                    atime=tokn.nextToken();
                    StringTokenizer sep1=new StringTokenizer(atime);
                    time1=sep1.nextToken();
                    meridian=sep1.nextToken();
                    StringTokenizer tk1=new StringTokenizer(time1,":");
                    hr=tk1.nextToken();
                    ihr=Integer.parseInt(hr);
                    min=tk1.nextToken();
                    if(meridian.equals("PM"))
                    {
                        ihr+=12;
                        flgg=1;
                    }
                    
                    if(flgg==1)
                    {
                       arrTime=String.valueOf(ihr)+min;
                    }
                    else
                       arrTime=hr+min; 
                    via=tokn.nextToken();
                    eFrom=tokn.nextToken();
                    StringTokenizer t1 = new StringTokenizer(eFrom);
                    dt1=Integer.parseInt(t1.nextToken());
                    m1=t1.nextToken();
                    y1=Integer.parseInt(t1.nextToken());
                    for(j=0;j<12;j++)
                        if(m1.equalsIgnoreCase(mon[j]))
                            break;
                    //System.out.println("From " + eFrom + " " + dt1 + " " + m1 + " " + y1);
                    p=j;
                    //System.out.println(p);
                    if(y1==16){
                        if(p<8){
                        st=1;//start date
                        p=8;}
                        else if(p>=8 && p<=10){
                        if((p==10 && dt1<14)|| p<10){
                        st=dt1;
                        }}}
                    //System.out.println(st);

                    eTill=tokn.nextToken();
                    StringTokenizer t2 = new StringTokenizer(eTill);
                    dt=Integer.parseInt(t2.nextToken());
                    m=t2.nextToken();
                    y=Integer.parseInt(t2.nextToken());
                    //System.out.println("Till " + eTill + " " + dt + " " + m + " " + y);
                    for(j=0;j<12;j++)
                        if(m.equals(mon[j]))
                            break;
                    
                    p1=j;
                    if(y==16){
                    if(p1>=8 && p1<=10){
                    if((p1==10 && dt<14)|| p1<10){
                    end=dt;//end date
                    }
                    else{
                    end=13;}
                    }
                    if(p1>10){
                    end=13;
                    p1=10;}
                    }
                    else{
                        end=13;
                        p1=10;
                    }
                    //System.out.println(end+" "+q++);
                    StringTokenizer t3 = new StringTokenizer(daysOfWeek,", ");
                    count1=0;
                    while(t3.hasMoreTokens())
                    {   
                        w[count1++]=t3.nextToken();
                    }
                    if(w[0].equals("DAILY"))
                    {
                        for(j1=0;j1<7;j1++)
                        w[j1]=days[j1];
                        count1=7;
                    }
                    if(p==9)
                     x=st+30;//x and y used as markers
                    if(p==10)
                     x=st+61;
                    if(p1==9)
                     x1=end+30;
                    if(p1==10)
                     x1=end+61;
                    for(j=x;j<=x1;j++){
                    for(j1=0;j1<count1;j1++){
                    if(w[j1].equalsIgnoreCase(d[j])){
                    if(f1==0){
                    if(j<=30){
                    d2=j;
                    m2=9;}
                    else if(j>30 && j<=61){
                    d2=j-30;
                    m2=10;}
                    else{
                    d2=j-61;
                    m2=11;}
                    //System.out.println(flightNum+"|"+m2+"/"+d2+"/"+"2016"+"|"+d[j]+"|"+15);
                    pw.println(flightNum+"|"+m2+"/"+d2+"/"+"2016"+"|"+d[j]+"|"+15);
                    break;
                    }}}}

                    //System.out.println("arrtime= "+arrTime);
                   // System.out.println("deptime= "+depTime);
                    dom[count]=new Flight(depCity,arrCity,daysOfWeek,flightNum,depTime,arrTime);
                    count++;
                }
            }
            br.close();
            //System.out.println("Whasaa!");
           
            FileReader fr1=new FileReader(silkaircsv);
            BufferedReader br1=new BufferedReader(fr1);
            for(j=0;j<19;j++)
            {
                line=br1.readLine();
                if(j>=3)
                {
                    //System.out.println(line);
                    StringTokenizer tokn = new StringTokenizer(line,"|");
                    int len=tokn.countTokens();
                    depCity=tokn.nextToken();
                    
                    arrCity= "Singapore";
                    daysOfWeek=tokn.nextToken();
                    flightNum=tokn.nextToken();
                    Time=tokn.nextToken();
                    StringTokenizer st2 = new StringTokenizer(Time,"/");
                    depTime=st2.nextToken();
                    arrTime=st2.nextToken();
                    StringTokenizer t4 = new StringTokenizer(daysOfWeek,",");
                    count1=0;
                    while(t4.hasMoreTokens())
                    {
                        w[count1++]=t4.nextToken();
                    }
                    if(w[0].equalsIgnoreCase("DAILY"))
                    {
                        for(j1=0;j1<7;j1++)
                        w[j1]=days[j1];
                        count1=7;
                    }
                    if(len>4){
                    remark=tokn.nextToken();
                    remark=remark.trim();}
                    if(len==4){
                        x=1;
                        x1=74;
                    }
                    if(len>4){
                        //System.out.println(remark);
                     if(remark.charAt(0)=='D'){
                        if(remark.length()>11){
                            if(remark.charAt(11)==','){
                            ex_1=remark.substring(21,23);
                            ex1=Integer.parseInt(ex_1)+30;
                            ex_2=remark.substring(28,30);
                            ex2=Integer.parseInt(ex_2)+30;
                            ex_3=remark.substring(35,37);
                            ex3=Integer.parseInt(ex_3)+30;
                        
                            z=remark.substring(9,11);
                            z=z.trim();
                            x=1;
                            x1=Integer.parseInt(z)+30-1;
                          }}
                        else{
                            z=remark.substring(9);
                        z=z.trim();
                        x=1;
                        x1=Integer.parseInt(z)+30-1;
                        }
                    }
                    else if(remark.charAt(0)=='E'){
                        z=remark.substring(8);
                        z=z.trim();
                        x1=74;
                        x=Integer.parseInt(z)+30;
                    }
                    else if(remark.charAt(0)=='S'){
                        z=remark.substring(3,5);
                        z=z.trim();
                        x=Integer.parseInt(z);
                        z1=remark.substring(11,13);
                        z1=z1.trim();
                        x1=Integer.parseInt(z1)+30;
                    }
                    else if(remark.charAt(0)=='O'){
                        z=remark.substring(3,4);
                        z=z.trim();
                        x=Integer.parseInt(z)+30;
                        z1=remark.substring(10,12);
                        z1=z1.trim();
                        x1=Integer.parseInt(z1)+30;
                    }
                    }
                    //System.out.println(x+" "+x1+" "+ex1+" "+ex2+" "+ex3);
                    //System.out.println(count1);
                    int g=0;
                    for(i=0;i<count1;i++)
                        //System.out.println(w[i]);
                    for(i=x;i<=x1;i++)
                    {
                        
                        if(i==ex1 || i==ex2 || i==ex3){
                            g=1;
                        }
                        if(g!=1){
                            //System.out.println(i);
                        for(j1=0;j1<count1;j1++)
                            
                        {
                            if(d[i].startsWith(w[j1]))
                            {
                                //System.out.println(j1);
                                if(f1==0){
                                    
                                    if(i<=30){
                                    d2=i;
                                    m2=9;}
                                    else if(i>30 && i<=61){
                                    d2=i-30;
                                    m2=10;}
                                    else
                                    {
                                    d2=i-61;
                                    m2=11;}
                                //System.out.println(flightNum+"|"+m2+"/"+d2+"/"+"2016"+"|"+d[i]+"|"+15);
                                pw.println(flightNum+"|"+m2+"/"+d2+"/"+"2016"+"|"+d[i]+"|"+15);
                                break;}
                            }
                        }}
                        g=0;
                    }
                    ex1=ex2=ex3=0;
                    
                    inter[count2]=new Flight(depCity,arrCity,daysOfWeek,flightNum,depTime,arrTime);
                    count2++;
                }
            }
            pw.close();
            br1.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("NO SUCH FILE EXISTS");
        }
        catch(IOException e)
        {
            System.out.println("IO ERROR!!!");
        }
    }

     Flight[] readSpicejet() {
        
        return dom;
    }

     Flight[] readSilkair() {
        
        return inter;
    }
    
}
