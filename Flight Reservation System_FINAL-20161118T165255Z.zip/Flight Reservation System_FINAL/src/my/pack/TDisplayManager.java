/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;
import java.util.*;
import java.io.*;
/**
 *
 * @author Bisho
 */
public class TDisplayManager implements DisplayManager {
    FRSmanager ob;SearchManager srm;
    TDisplayManager(FRSmanager mg,SearchManager srm)
    {
        ob=mg;
        this.srm=srm;
    }
    Scanner sc =new Scanner(System.in);
    public static String fld,fli,itd,Name;
    public ComboFlights ck[];
    String ref,date;
    
    public String getName(){
        //Skip newline
        sc.nextLine();
        System.out.println("\nEnter your name: ");
        String nm = sc.nextLine();
        return nm;
    }
    
    @Override
    public void show_screen1()
    {
        String num,dat,source,dat1,dat2;
        int flag=0;
        String ch;
        System.out.println("\n");
        System.out.println("-------------------------------------------------------------------");
        System.out.println("              WELCOME TO FLIGHT RESERVATION SYSTEM!!!!!                       ");
        System.out.println("-------------------------------------------------------------------");
            while(true)
            {
        System.out.println("Please Select the Source City:(DELHI/MUMBAI/PUNE)");
        System.out.println("Destination is Singapore");
        System.out.println();
        source=sc.next();
        if(source.equals("DELHI") || source.equals("MUMBAI") ||source.equals("PUNE"))
            break;
        else
        {
            System.out.println("Enter source city Correctly: ");
            continue;
        }
            }
            while(true){
        System.out.println("\nEnter No. of Seats: (You can book maximum of 10 tickets at once)");
        num=sc.next();
        if(Integer.parseInt(num) <1 || Integer.parseInt(num)>10)
            System.out.println("Enter seats between 1-10");
        else
            break;
            }
            while(true)
            {
                flag=0;
        System.out.println("\nEnter date of journey: (dd/mm/yyyy)\nNote:You can only travel between 1st September and 13th November 2016");
        dat=sc.next();
        if(dat.length()==10){
         date=dat;
        dat=date.substring(0, 2);
        dat1=date.substring(3, 5);
        dat2=date.substring(6, 10);
        if(((Integer.parseInt(dat1)<9)&&(Integer.parseInt(dat1)>10))||((Integer.parseInt(dat1)==11)&&(Integer.parseInt(dat)>13))||(Integer.parseInt(dat2)!=2016)||(date.length()!=10))
            flag=1;
        if(flag==1)
        {
            System.out.println("Enter the date in correct format, try again !!");
        }
        else
            break;
        }
        else
            System.out.println("Enter the date in correct format, try again !!");
            }
            System.out.println("\nYour details are as follows: ");
            System.out.println("Date of Journey: "+date);
            System.out.println("Source City: "+source);
            System.out.println("Number of Tickets: "+num);
            System.out.println("Proceed?? y/n");
            
             while(true)
             {
                  ch=sc.next();
        if(ch.equals("y"))
        {
        ob.search(source, dat, num, dat1);
        break;
        }
        else if(ch.equals("n")==false || ch.length()>1)
        {
            System.out.println("Enter valid choice!!!!");
        }
        else
        {
          System.out.println("Good Bye!!! Have a nice day!!!");  
           System.out.println("-------------------------------------------------------------------");
          System.out.println("-------------------------------------------------------------------");
            break;
          //System.exit(0);
        }
             }
            }
    @Override
    public void show_screen2(ComboFlights cf[])
    {
        if(srm.c==0)
        {  System.out.println("\nSorryyy!!!!:( No connections possible !!");
        ob.start(ob);
        }
        String ch;
         ck=cf;
         ComboFlights selectedCombo;
        int ai,ad,id,td,choice,flag=0,i1=0;
        System.out.println("                      ************Search Results************                                               \n");
        System.out.println("  FLIGHT    SOURCE       DESTINATION       DEPARTURE      ARRIVAL     DURATION\n");
                String sp="  ";
                for( int i=0;i<srm.c;i++)
                {
                   System.out.print(i+1+". ");
                   
                   int ss=cf[i].international.depCity.length();
                   itd=cf[i].international.depCity.substring(0, ss-6);
                   itd=itd.toUpperCase();
                   makestr(i);
                   ai =calctime(ck[i].international.depTime,ck[i].international.arrTime);
                   ad =calctime(ck[i].domestic.depTime,ck[i].domestic.arrTime);
                   id =calctime(ck[i].domestic.arrTime,ck[i].international.depTime);
                   td=((ad%100)+(ai%100)+(id%100))%60+((((ad/100)+(ai/100)+(id/100))+((ad%100)+(ai%100)+(id%100))/60)*100);
                   
                   int ji=(td%100)-30;
                   if(ji<0)
                           {
                          td=(td/100)-3;
                          ji+=60;
                   }
                   else
                       td=(td/100)-2;
                   System.out.println(fld);
                   System.out.print(fli+"     ");
                   System.out.println(td+"h"+ji+"m");
                   System.out.println("==============================================================================");
                   
                } 
                System.out.println("\n   Enter your choice:  \n");
                while(true){
                choice=Integer.parseInt(sc.next());
                if((choice<=srm.c)&&!(choice<0))
                    break;
                else
                    System.out.println("Enter a valid choice");
                }
                for(int i=0;i<srm.c;i++)
                    {
                        if(choice==i+1)
                        {
                            flag=1;
                            i1=i;
                           // break;
                        }
                    }
                    if(flag==1)
                    {
                        System.out.println("You have selected "+ck[i1].domestic.flightNum+" Spicejet and \n"+ck[i1].international.flightNum+" Silkair Flight");
                        System.out.println("\nProceed to Booking?? y/n");
                        
                        selectedCombo=ck[i1];
                        while(true)
                        {
                            ch=sc.next();
                        if(ch.equals("y"))
                        {
                        ob.book(selectedCombo);
                        ob.showScreen3();
                        break;
                        }
                        else if(ch.equals("n")==false || ch.length()>1)
                        {
                            System.out.println("Enter valid choice.");
                        }
                        else
                        {
                            System.out.println("Good Bye!!! Have a nice day!!!"); 
                        System.out.println("-------------------------------------------------------------------");
                        System.out.println("-------------------------------------------------------------------");
                        break;
                        }
                        }

                         System.out.println();
                    }    
    }
    @Override
    public void showScreen3(ComboFlights cmb, String nm, int tick, String dt, String ref, String mon)
    {  
        String ch;
        System.out.println("-------------------------------------------------------------------");
          System.out.println("-------------------------------------------------------------------");
          System.out.println("                        ------>  BOOKING  <--------                            \n");
        System.out.println("----------------------------------------------------------------------");
          System.out.println("Name :"+nm);
        System.out.println("No. of Tickets: "+String.valueOf(tick));
        System.out.println("Booking Reference number: "+ref);
        System.out.println("Date of Travel: "+dt+ " " + mon + " '16");
        System.out.println(cmb.domestic.flightNum+" : "+cmb.domestic.depCity+" ("+cmb.domestic.depTime+") - "+cmb.domestic.arrCity+" ("+cmb.domestic.arrTime+")");
        System.out.println(cmb.international.flightNum+" : "+cmb.international.depCity+" ("+cmb.international.depTime+") - "+cmb.international.arrCity+" ("+cmb.international.arrTime+")");
        System.out.println("\n\nCongrats!!! Your Booking is successful!!!\n");
        System.out.println("\nPlease Make a choice: ");
        System.out.println("1.Book another Ticket.\n2.Exit");
        while(true)
        {
        ch=sc.next();
        if(ch.equals("1"))
        {
            ob.start(ob);
            break;
        }
        else if(ch.equals("2")==false || ch.length()>1)
        {
            System.out.println("Enter valid choice.");
        }
        else
        {
         System.out.println("Good Bye!!! Please Visit us again!!!! :)");  
         System.out.println("-------------------------------------------------------------------");
         System.out.println("-------------------------------------------------------------------");
         break;
        }
        }
        
    }
     
    
    void makestr(int as)
                        {
                       fli="   "+ck[as].international.flightNum;
                            int le=fli.length();
                            int io;
                            while(fli.length()<12)
                            {
                            fli=fli+" ";
                            }
                            fli=fli+itd;
                            le=fli.length();
                            if(itd.length()<=5)
                                fli=fli+"  ";
                            for(io=le;io<31;io++)
                            {
                            fli=fli+" ";
                            }
                            fli=fli+"SINGAPORE";
                            le=fli.length();
                            for(io=le;io<49;io++)
                            {
                            fli=fli+" ";
                            }
                           
                            fli=fli+ck[as].international.depTime;
                            le=fli.length();
                            
                            for(io=le;io<61;io++)
                            {
                            fli=fli+" ";
                            }
                            fli=fli+ck[as].international.arrTime;
                            fld= ck[as].domestic.flightNum+"  "+ck[as].domestic.depCity;
                            le=fld.length();
                            for(io=le;io<30;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.arrCity;
                            le=fld.length();
                            if(ck[as].domestic.arrCity.length()<=7)
                                fld=fld+" ";
                            for(io=le;io<46;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.depTime;
                            le=fld.length();
                            if(ck[as].domestic.arrCity.length()<=7)
                                fld=fld+"  ";
                            for(io=le;io<60;io++)
                            {
                            fld=fld+" ";
                            }
                            fld=fld+ck[as].domestic.arrTime;
                        }
    int calctime(String y,String z)
    {
        int ti=0,yy,zz,l1,l2;
        if(z.length()!=4)
        {
            z=z.substring(0,4);
         }
        yy=Integer.parseInt(y);
        zz=Integer.parseInt(z);
        l1=yy%100;
        l2=zz%100;
        yy/=100;
        zz/=100;
        if(z.length()==4 && zz>yy)
        {
        if(l2>=l1)
            ti=(100*(zz-yy))+l2-l1;
        else
            ti=(100*(zz-yy-1))+60-l1+l2;
        }
        else
        {
        if(l1==0){
            yy=24-yy;
        }
        else{
            yy=24-yy-1;
            l1=60-l1;
        }
        l1+=l2;
        yy+=zz;
        yy+=l1/60;
        l1=l1%60;
        ti=(100*yy)+l1;
        }
        return ti;
    }
   
    
}
