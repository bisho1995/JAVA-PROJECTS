/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.pack;

/**
 *
 * @author Bisho
 */
public class GDisplayManager implements DisplayManager{
    FRSmanager mgr;SearchManager srm;
    Screen1 ob1;
    Screen2 ob2;
    Screen3 ob3;
    GDisplayManager(FRSmanager mg,SearchManager sr)
    {
        mgr=mg;
        srm=sr;
        this.ob1 = new Screen1(mgr,srm);
        this.ob2 = new Screen2(mgr,srm);
        this.ob3 = new Screen3(mgr);
    }
     @Override
    public void show_screen1()
    {
       ob1.setVisible(true);
    }
     @Override
  public void show_screen2(ComboFlights cf[])
    {
        ob2.setVisible(true);
        ob2.show_sorted_combo(cf);
     }
     @Override
    public void showScreen3(ComboFlights cmb, String nm, int tick, String dt, String ref,String mon) {
        ob3.setVisible(true);
        ob3.showDetails(cmb,nm,tick,dt,ref,mon);  
    }
    public String getName()
    {
        return ob2.Name;
    }
            
}

    